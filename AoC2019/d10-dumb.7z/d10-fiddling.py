import math
import sys
import copy
from collections import defaultdict, OrderedDict
from PIL import Image
import numpy as np


def renderboard(board, loc="d10\\frame0.png", overlay=None):
    to_render = copy.deepcopy(board)
    for y, line in enumerate(board):
        for x, tile in enumerate(line):
            if tile == '#':
                to_render[x][y] = 2
            else:
                to_render[x][y] = 0
    if overlay is not None:
        for k, v in overlay.items():
            if v == '@':
                to_render[k[0]][k[1]] = 1
            else:
                to_render[k[0]][k[1]] = 3
    to_render = np.swapaxes(np.array(to_render, dtype=np.uint8), 0, 1)
    print(to_render)
    palette = [0,0,0, 0x00,0xFF,0x00, 0x77,0x77,0x77, 0x30, 0x30, 0x30]

    img = Image.fromarray(to_render, "P")
    img.putpalette(palette)
    # img.show()
    img.save(loc)


def render(board, dim, overlay=None):
    if overlay is None:
        overlay = {}
    tostr = []
    for y in range(dim[0]):
        for x in range(dim[1]):
            if (x, y) in overlay:
                tostr.append(overlay[(x, y)])
            else:
                tostr.append(board[y][x])
            tostr.append(" ")
        tostr.append("\n")
    return "".join(tostr)


def has_los(start, end, board_data):
    rel = (start[0] - end[0], start[1] - end[1])
    step_x, step_y = rel

    for i in range(max(abs(step_x), abs(step_y))+1, 0, -1):
        if (step_x % i) == 0 and (step_y % i) == 0:
            step_x //= i
            step_y //= i
    step = (step_x, step_y)

    cur = (end[0] + step[0], end[1] + step[1])

    while cur != start:
        if cur in board_data['asteroids']:
            return False
        cur = (cur[0] + step[0], cur[1] + step[1])

    return True


def vaporize(start, end, board_data):
    rel = (start[0] - end[0], start[1] - end[1])
    step_x, step_y = rel

    for i in range(max(abs(step_x), abs(step_y))+1, 0, -1):
        if (step_x % i) == 0 and (step_y % i) == 0:
            step_x //= i
            step_y //= i
    step = (step_x, step_y)

    cur = (end[0] + step[0], end[1] + step[1])

    while cur != start:
        if cur in board_data['asteroids']:
            return False
        cur = (cur[0] + step[0], cur[1] + step[1])

    return True


def euclid_dist(a, b):
    return math.sqrt(math.pow((a[0]-b[0]), 2) + math.pow((a[1]-b[1]), 2))


f = 'd10.txt'
if len(sys.argv) > 1:
    f = sys.argv[1]
board = [[c for c in ln.strip()] for ln in open(f).readlines()]

board = [c for c in board]
board_data = {'height': len(board), 'width': len(board[0])}

asteroids = set()
for y, line in enumerate(board):
    for x, tile in enumerate(line):
        if tile == '#':
            asteroids.add((x, y))
board_data['asteroids'] = asteroids


can_see = copy.deepcopy(board)

best = (0, (0, 0))
for a1 in asteroids:
    ct = 0
    for a2 in asteroids:
        if a1 == a2:
            continue
        elif has_los(a1, a2, board_data):
            ct += 1
    can_see[a1[1]][a1[0]] = str(ct)
    if best[0] < ct:
        best = ct, a1

# print(render(can_see, (board_data['height'], board_data['width'])))
print('p1:', best)

bins = defaultdict(list)
for a in asteroids:
    # print('rel', best[1][0] - a[0], best[1][1] - a[1])
    bins[(math.atan2(a[0] - best[1][0], a[1] - best[1][1]))*-1].append(a)
print(bins)

for b, c in bins.items():
    c.sort(key=lambda k: euclid_dist(k, best[1]), reverse=True)

print(sorted(bins))
s = [bins[k] for k in sorted(bins)]
print(s)
popped = []
i = 0
display = {}
while i < 400:
    print(s)
    print(i, s[i])
    if len(s[i]) > 0:
        popped.append(s[i].pop())
        display[popped[-1]] = '~'
        print(display)
        display[best[1]] = '@'
        renderboard(board, "d10\\frame" + str(i).zfill(6) + ".png", display)
        i += 1
    # print(popped[-1])
    # print(render(board, (board_data['height'], board_data['width']), display))

print(popped[-1][0] * 100 + popped[-1][1])


# 1508 too high