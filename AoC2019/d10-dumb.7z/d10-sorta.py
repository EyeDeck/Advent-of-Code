import sys
import numpy as np
from collections import defaultdict
import copy


def render(board, dim, overlay=None):
    if overlay is None:
        overlay = {}
    tostr = []
    for y in range(dim[0]):
        for x in range(dim[1]):
            if (x, y) in overlay:
                tostr.append(overlay[(x, y)])
            else:
                tostr.append(board[y][x])
            tostr.append(" ")
        tostr.append("\n")
    return "".join(tostr)


def has_los(start, end, board_data):
    rel = tuple(np.subtract(start, end))
    step_x, step_y = rel

    while step_x % 2 == 0 and step_y % 2 == 0 and (step_x != 0 or step_y != 0):
        step_x //= 2
        step_y //= 2

    if abs(step_x) == abs(step_y) or step_x == 0 or step_y == 0:
        if step_x != 0:
            step_x = 1 if abs(step_x) == step_x else -1
        if step_y != 0:
            step_y = 1 if abs(step_y) == step_y else -1

    step = (step_x, step_y)

    cur = tuple(np.add(end, step))
    # print('start', start, 'end', end, 'rel', rel, 'cur', cur, 'step', step)
    while cur != start:
        # print(cur)
        if cur[0] < 0 or cur[1] < 0 or cur[0] > board_data['width'] or cur[1] > board_data['height']:
            print('bad process')
            input()
        if cur in board_data['asteroids']:
            print('start', start, 'end', end, 'rel', rel, 'cur', cur, 'step', step)
            print(start, end, 'obscured by', cur)
            print(render(board, (board_data['height'], board_data['width']), {start: 'S', end: 'E', cur: 'X'}))
            input()
            # print(render(board, board_data, {start: 'S', end: 'E', cur: 'X'}))
            return False
        cur = tuple(np.add(cur, step))
    # print('start', start, 'end', end, 'rel', rel, 'cur', cur, 'step', step)
    # print(start, end, 'no obstruction', cur)
    # print(render(board, (board_data['height'], board_data['width']), {start: 'S', end: 'E'}))
    return True

#    for a in asteroids:
#        print(a)


f = 'd10-e.txt'
if len(sys.argv) > 1:
    f = sys.argv[1]
board = [[c for c in ln.strip()] for ln in open(f).readlines()]
print(board)
board = [c for c in board]
board_data = {'height': len(board), 'width': len(board[0])}
print(render(board, (board_data['height'],board_data['width'])))
print(board_data)

asteroids = set()
for y, line in enumerate(board):
    for x, tile in enumerate(line):
        if tile == '#':
            asteroids.add((x, y))
board_data['asteroids'] = asteroids

print(asteroids)

can_see = copy.deepcopy(board)
print(board)
print(can_see)
best = 0
for a1 in asteroids:
    print('a1', a1)
    ct = 0
    for a2 in asteroids:
        if a1 == a2:
            continue
        elif has_los(a1, a2, board_data):
            ct += 1
    can_see[a1[1]][a1[0]] = str(ct)
    print(ct, a1)
    best = max(ct, best)
print(render(can_see, (board_data['height'], board_data['width'])))
print('p1:', best)